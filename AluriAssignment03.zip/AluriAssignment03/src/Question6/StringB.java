package Question6;

public class StringB {
	
	public static void main(String[]args)
	{
	StringBuilder sbld = new StringBuilder("StringBuilder to StringBuffer");
	StringBuffer sb2 = new StringBuffer(sbld);

System.out.println( sb2 );
}

}
