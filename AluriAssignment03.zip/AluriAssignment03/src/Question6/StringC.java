package Question6;

public class StringC {
	public static void main(String args[])
	{
	String str="I am string";
	str.concat(" I am instance of String class.");
	System.out.println(str);
	}
}
