package Question3;

public class CovariantBaseClass {
   
	CovariantBaseClass get() {
	      System.out.println("SuperClass");
	      return this;
	   }

	
}
