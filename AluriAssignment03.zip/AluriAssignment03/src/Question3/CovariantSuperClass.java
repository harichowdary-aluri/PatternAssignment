package Question3;

public class CovariantSuperClass extends CovariantBaseClass {

	CovariantSuperClass get() {
	      System.out.println("SubClass");
	      return this;
	   }
	   public static void main(String[] args) {
		   CovariantBaseClass tester = new CovariantSuperClass();
	      tester.get();
	   }
}
