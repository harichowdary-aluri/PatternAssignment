package Question10;

public class AClass {
	public void sampleMethod()throws FileNotFoundException{
	      System.out.println("Method of superclass");
	   }
}
