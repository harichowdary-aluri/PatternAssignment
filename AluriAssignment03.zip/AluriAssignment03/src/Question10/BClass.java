package Question10;

public class BClass extends AClass{
	public void sampleMethod() {
	      System.out.println("Subclass");
	   }
	   public static void main(String args[]) {
		   BClass obj = new BClass();
	      obj.sampleMethod();
	   }
}
