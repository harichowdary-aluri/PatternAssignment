package Question7;

public class FinCon {
    final FinCon()
    {
    	System.out.println("this is the final constructor");
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinCon fc = new FinCon();
	}

}
