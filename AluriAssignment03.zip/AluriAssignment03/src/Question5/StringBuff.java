package Question5;

public class StringBuff {
	//String to StringBuffer
	public static void main(String[]args)
	{
	String str = "String to StringBuffer";
	StringBuffer sb1 = new StringBuffer(str);
	System.out.println( sb1 );
	}
}
