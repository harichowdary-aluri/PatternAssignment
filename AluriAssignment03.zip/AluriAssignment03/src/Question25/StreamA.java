package Question25;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamA {
	public static void main(String args[])
	  {
		List<Integer> number = Arrays.asList(2,3,4,5);
	   
	    
	  
	    
	    List<Integer> numbers = Arrays.asList(2,3,4,5,2);
	  
	  
	    Set<Integer> squareSet =
	         numbers.stream().map(x->x*x).collect(Collectors.toSet());
	    System.out.println(squareSet);
	  

	  }

}
