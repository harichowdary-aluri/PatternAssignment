package Question12;

public class FinallyInJava {

	protected void finalize() throws Throwable
	{
		try {

			System.out.println("inside demo's finalize()");
		}
		catch (Throwable e) {

			throw e;
		}
		finally {

			System.out.println("Calling finalize method"
							+ " of the Object class");

			// Calling finalize() of Object class
			super.finalize();
		}
	}
	public static void main(String[] args) {
		
		

			// Driver code
			
				// Creating demo's object
		FinallyInJava d = new FinallyInJava();
        d.finalize();

		}

}
