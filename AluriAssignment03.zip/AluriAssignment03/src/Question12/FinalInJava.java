package Question12;

public class FinalInJava {
	 final int age=90; 
	 void run(){  
	                                            age=40;  
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalizeInJava FIJ = new FinalizeInJava();

	}

}
