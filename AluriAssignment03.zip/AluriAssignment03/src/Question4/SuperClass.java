package Question4;

public class SuperClass extends BaseClass{

	private void hari() {
	      System.out.println("Super class");    
	   } 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseClass b = new SuperClass();
		b.hari();

	}

}
