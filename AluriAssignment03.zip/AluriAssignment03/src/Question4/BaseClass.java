package Question4;

public class BaseClass {
 
	private void hari() {
	      System.out.println("BASECLASS");    
	   }
}
