package Question4;


public class Base {
	 void display()  {
	     System.out.println("Sub class");
	  }
		   public static void main(String[] args) {
			      superC obj = new superC();
			      obj.display();
			   }
	}

