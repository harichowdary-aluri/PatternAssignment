package Question4;

public class superC {
	static void display() {
	      System.out.println("Super class");    
	   }

}
