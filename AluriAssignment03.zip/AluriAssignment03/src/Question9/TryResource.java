package Question9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryResource {
    
	static String readFirstLineFromFile(String path) throws IOException {
	    try (FileReader fr = new FileReader(path);
	         BufferedReader br = new BufferedReader(fr)) {
	        return br.readLine();
	    }
	} 
	
	public static void main(String[] args) {
		
		TryResource TR = new TryResource();
		TR.readFirstLineFromFile(Hari.txt);
	}

}
