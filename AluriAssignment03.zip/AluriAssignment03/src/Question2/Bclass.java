package Question2;

public class Bclass extends CClass {

	void method()
    {
        System.out.println("Hello");
    }
	  public static void main(String args[])
	    {
		  Bclass   b = new Bclass();
	        b.method();
	    }
}
