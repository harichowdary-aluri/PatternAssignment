package Question2;

public class CClass {
	 protected void method()
	    {
	        System.out.println("Hello");
	    }
}
