package Question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class Synchronized1 {

	 public static void main (String[] args)
	    {
	        List<String> list =
	           Collections.synchronizedList(new ArrayList<String>());
	 
	        list.add("Anju");
	        list.add("Hari");
	        list.add("Sindhu");
	 
	        synchronized(list)
	        {
	            Iterator it = list.iterator();
	 
	            while (it.hasNext()) {
	                System.out.print(it.next());
	        }
	        }
	    }
}
