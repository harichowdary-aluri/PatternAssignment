package Generics;

public class Generic {
	
	 public static <T> void genric(T t)
	 {
		 System.out.println("it is"+" "+t);
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		genric("Hari");
       Integer myint =1;
       genric(myint);
       genric(true);
       
	}

}
